import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { first } from 'rxjs/operators';
import { Login } from '../../models/login.model';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  LoggedInUserId: number; // variable to hold user ID of logged in user
  userName: string; // variable for username
  isUserLoggedIn = false; // variable for user log in status
  displayLogin = true; // variable for login display
  loginForm: FormGroup; // form group variable
  submitted = false; // initially submit  flase
  isLoginError = false; /// variable handling errors
  notValidLogin = false; // variable handlling not valid login
  userId = 0; // variable that hold the user ID of user
  loading = false;

  //For Json data
  loginDetail: Login;
  selectedUsername: any;
  selectedPassword: any;
  loginStatus: any;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });

    this.loginDetail = new Login();
    this.loginStatus = '';
  }

  get getForm() { return this.loginForm.controls; }


  onSubmit() {

    var loginDataList = [
      { 'username': 'abc', 'password': 'abc123' },
      { 'username': 'abcd', 'password': 'abc1234' },
      { 'username': 'richa', 'password': 'richa123' }
    ];

    var userAndPasswordPresent = false;
    for (var i in loginDataList) {
      if (loginDataList[i].username === this.selectedUsername && loginDataList[i].password === this.selectedPassword) {
        this.loginDetail.username = this.selectedUsername;
        this.loginDetail.password = this.selectedPassword;
        console.log(this.loginDetail);
        console.log('success..!!');
        userAndPasswordPresent = true;
        break;
      }
      else {
        console.log('login failed..!!');
        this.loginStatus = 'Username or password is incorrect';
      }
    }


    // this.submitted = true;
    // this.notValidLogin = false;
    // // stop here if form is invalid
    // if (this.loginForm.invalid) {
    //   return;
    // }
    // //Authentication section
    // else {
    //   this.authenticationService.userAuthentication(this.loginForm.value.username, this.loginForm.value.password).pipe(first()).subscribe(
    //     data => {
    //       this.router.navigate([RedirectUrl.Dashboard]);
    //     },
    //     //Error messages to be displayed
    //     error => {
    //       this.notValidLogin = true;
    //     });      
    //   }
  }
}
