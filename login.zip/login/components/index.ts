import {UserLoginComponent} from './user-login/user-login.component';
export const components = [
    UserLoginComponent
];
export * from './user-login/user-login.component';