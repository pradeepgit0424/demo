import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
// import { LoginRoutingModule } from './login-routing.module';
import { RouterModule } from '@angular/router';
import * as loginComponents from './components';
import * as loginContainers from './containers';

/* Guards */
import * as loginGuards from './guards';

/* Services */
import * as loginServices from './services';
// import { UserLoginComponent } from './components/user-login/user-login.component';
@NgModule({
  
  imports: [
    CommonModule,
    // LoginRoutingModule,
    RouterModule,
    ReactiveFormsModule,
    FormsModule,
    NgSelectModule,
    NgbModule,
    // UserLoginComponent,
  



  ],
  providers: [...loginServices.services, ...loginGuards.guards],
  declarations: [...loginContainers.containers, ...loginComponents.components],
  exports: [...loginContainers.containers, ...loginComponents.components],
})
export class LoginModule { }
