import { LoginService } from './login.service';

export const services = [LoginService];

export * from './login.service';