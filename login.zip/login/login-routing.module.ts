import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import * as loginContainers  from './containers';
import { LoginModule } from './login.module';
import * as loginGuards from './guards';
import * as loginComponents from './components';

export const ROUTES: Routes = [
  {
    path: '',
    canActivate: [],
    component: loginContainers.LoginComponent,
  }
];


@NgModule({
  imports: [LoginModule, RouterModule.forChild(ROUTES)],
  exports: [RouterModule],
})
export class LoginRoutingModule { }
