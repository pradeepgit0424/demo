/*
 * Public API Surface of ngx-text-box
 */

export * from './lib/ngx-text-box.service';
export * from './lib/ngx-text-box.component';
export * from './lib/ngx-text-box.module';
