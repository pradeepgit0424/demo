import { TestBed } from '@angular/core/testing';

import { NgxTextBoxService } from './ngx-text-box.service';

describe('NgxTextBoxService', () => {
  let service: NgxTextBoxService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NgxTextBoxService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
