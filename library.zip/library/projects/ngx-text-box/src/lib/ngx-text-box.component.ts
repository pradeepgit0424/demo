import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'NgxText-NgxTextBox',
  template: `
  <div>
  <p>Text-box Input </p>
      <input type="text" [style.color]="color">
      </div>
  `,
  styles: []
})
export class NgxTextBoxComponent implements OnInit {
  @Input() color: string = 'red';

  constructor() { }

  ngOnInit(): void {
  }

}
