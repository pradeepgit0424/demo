import { NgModule } from '@angular/core';
import { NgxTextBoxComponent } from './ngx-text-box.component';



@NgModule({
  declarations: [NgxTextBoxComponent],
  imports: [
  ],
  exports: [NgxTextBoxComponent]
})
export class NgxTextBoxModule { }
