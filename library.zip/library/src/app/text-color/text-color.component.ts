import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-text-color',
  templateUrl: './text-color.component.html',
  styleUrls: ['./text-color.component.css']
})
export class TextColorComponent{

  @Input() color: string = 'red';

}
