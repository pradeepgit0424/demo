import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TextColorComponent } from './text-color/text-color.component';


const routes: Routes = [

 //{ path: 'textColor', component: TextColorComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
