import socket
from HwAPI import *

hw_obj = HwAPI() 
serv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
Port = 8080 #Port to host server on
serv.bind(('0.0.0.0', Port))
serv.listen(5)
IP = socket.gethostname()
print("Server started at " + IP + " on port " + str(Port))


while True:
    conn, addr = serv.accept()
    print("New connection made!")
    from_client = ''
    while True:
        data = conn.recv(4096).decode()
        if not data: break
        print(data)
        hw_obj.exec_cmd(data.spn,data.val1)
        output = 'SampleOutPut123'
        conn.sendall(output.encode('utf-8'))
    conn.close()
    print('client disconnected')