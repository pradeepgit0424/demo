def testing_1(UCMnr, busnr, ic, potmeter, value):
    print("\n UCMnr : ", UCMnr, "\n busnr : ", busnr, "\n ic : ", ic, "\n potmeter : ", potmeter, "\n value : ", value)

def testing_2(Racknr, address, value1, value2):
    print("\n Racknr : ", Racknr, "\n address : ", address, "\n value1 : ", value1, "\n value2 : ", value2)

def testing_3(Racknr, address):
    print("\n rack_number : ", Racknr, "\n address : ", address)

def testing_4():
    print("\n inside analog read")

def testing_5(Racknr, channel, ADCnr):
    print("\n Racknr : ", Racknr, "\n channel : ", channel, "\n : ADCnr", ADCnr)