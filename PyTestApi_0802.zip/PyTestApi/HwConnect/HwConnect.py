import spidev
import RPi.GPIO as GPIO
import time
import smbus

class HwConnect:
    def __init__(self):
        print("inside init")

    #i2cbusRack1 = smbus.SMBus(7)
    #i2cbusRack2 = smbus.SMBus(8)
    #i2cbusRack3 = smbus.SMBus(9)
    #GPIO.setmode(GPIO.BCM)
    spi = spidev.SpiDev()
    # A0
    #GPIO.setup(4, GPIO.OUT, initial=GPIO.LOW)
    time.sleep(.10)
    # A1
    #GPIO.setup(23, GPIO.OUT, initial=GPIO.LOW)
    # A2
    #GPIO.setup(27, GPIO.OUT, initial=GPIO.LOW)
    # A3
    #GPIO.setup(22, GPIO.OUT, initial=GPIO.LOW)

    def writepotmeter_fn(self, UCMnr, busnr, ic, potmeter, value):
        #test purpose code
        print("Harwareconnect print")
        print("\n UCMnr : ", UCMnr, "\n busnr : ", busnr, "\n ic : ", ic, "\n potmeter : ", potmeter,  "\n value : ", value)
        return
        GPIO.output(4, (ic - 1) & 0x01)
        GPIO.output(23, ((ic - 1) & 0x02) >> 1)
        GPIO.output(27, ((ic - 1) & 0x04) >> 2)
        GPIO.output(22, ((ic - 1) & 0x08) >> 3)
        # GPIO.output(4, GPIO.LOW)0x18FFC000
        # GPIO.output(23, GPIO.LOW)
        # GPIO.output(27, GPIO.LOW)
        # GPIO.output(22, GPIO.LOW)
        # print ('output IC 1 set')

        if UCMnr == 1:
            if busnr == 0:
                spi.open(0, 0)
                spi.max_speed_hz = 100
                # print ('spi 0, 0 opened')
                spi.writebytes([potmeter, value])
                spi.close()
                # print ('spi 0, 0 closed')
            if busnr == 1:
                spi.open(0, 1)
                spi.max_speed_hz = 100
                # print ('spi 0, 1 opened')
                spi.writebytes([potmeter, value])
                spi.close()
                # print ('spi 0, 1 closed')
        if UCMnr == 2:
            if busnr == 0:
                spi.open(1, 0)
                spi.max_speed_hz = 100
                # print ('spi 1, 0 opened')
                spi.writebytes([potmeter, value])
                spi.close()
                # print ('spi 1, 0 closed')
            if busnr == 1:
                spi.open(1, 1)
                spi.max_speed_hz = 100
                # print ('spi 1, 1 opened')
                spi.writebytes([potmeter, value])
                spi.close()
                # print ('spi 1, 1 closed')
        if UCMnr == 3:
            if busnr == 0:
                spi.open(1, 2)
                spi.max_speed_hz = 100
                # print ('spi 1, 2 opened')
                spi.writebytes([potmeter, value])
                spi.close()
                # print ('spi 1, 2 closed')


    def analogInput_fn(self, Racknr, channel, ADCnr):
        GPIO.output(4, (ADCnr - 1) & 0x01)
        GPIO.output(23, ((ADCnr - 1) & 0x02) >> 1)
        GPIO.output(27, ((ADCnr - 1) & 0x04) >> 2)
        GPIO.output(22, ((ADCnr - 1) & 0x08) >> 3)
        if (Racknr == 1):
            spi.open(0, 0)
            spi.max_speed_hz = 1000
            adc = spi.xfer2([1, (8 + channel) << 4, 0])
            spi.close()
            data = ((adc[1] & 3) << 8) + adc[2]
            return data
        if (Racknr == 2):
            spi.open(1, 0)
            spi.max_speed_hz = 1000
            adc = spi.xfer2([1, (8 + channel) << 4, 0])
            spi.close()
            data = ((adc[1] & 3) << 8) + adc[2]
            return data
        if (Racknr == 3):
            spi.open(1, 2)
            spi.max_speed_hz = 1000
            adc = spi.xfer2([1, (8 + channel) << 4, 0])
            spi.close()
            data = ((adc[1] & 3) << 8) + adc[2]
            return data


    def adc_channel_read_fn(self):
        global var1_bis, var2_bis, var3_bis, var4_bis, var5_bis, var6_bis, var7_bis, var8_bis, var9_bis
        global buffer, AuxPTOValveOn, RotorIncr, RotorDecr, RotorClutchOn

        var1_bis = 0
        var2_bis = 0
        var3_bis = 0
        var4_bis = 0
        var5_bis = 0
        var6_bis = 0
        var7_bis = 0
        var8_bis = 0
        var9_bis = 0

        for Racknr in range(1, 3):
            if (Racknr == 1):
                data = [0, 0, 0, 0, 0, 0, 0, 0]
                for j in range(13, 17):
                    for i in range(0, 8):
                        data[i] = analogInput(Racknr, i, j)
                    if j == 13:
                        ADC1ValueRack1.delete(0, END)
                        ADC1ValueRack1.insert(0, (float(data[0]) * 5 / 1024))
                        if (float(data[0]) * 5 / 1024) > 2:
                            var2_bis = var2_bis + 1024
                        ADC2ValueRack1.delete(0, END)
                        ADC2ValueRack1.insert(0, (float(data[1]) * 5 / 1024))
                        if (float(data[1]) * 5 / 1024) > 2:
                            var2_bis = var2_bis + 256
                        ADC3ValueRack1.delete(0, END)
                        ADC3ValueRack1.insert(0, (float(data[2]) * 5 / 1024))
                        if (float(data[2]) * 5 / 1024) > 2:
                            var2_bis = var2_bis + 4096
                        ADC4ValueRack1.delete(0, END)
                        ADC4ValueRack1.insert(0, (float(data[3]) * 5 / 1024))
                        if (float(data[3]) * 5 / 1024) > 2:
                            var2_bis = var2_bis + 8
                        ADC5ValueRack1.delete(0, END)
                        ADC5ValueRack1.insert(0, (float(data[4]) * 5 / 1024))
                        if (float(data[4]) * 5 / 1024) > 2:
                            var2_bis = var2_bis + 128
                        ADC6ValueRack1.delete(0, END)
                        ADC6ValueRack1.insert(0, (float(data[5]) * 5 / 1024))
                        if (float(data[5]) * 5 / 1024) > 2:
                            var2_bis = var2_bis + 32
                        ADC7ValueRack1.delete(0, END)
                        ADC7ValueRack1.insert(0, (float(data[6]) * 5 / 1024))
                        if (float(data[6]) * 5 / 1024) > 2:
                            var2_bis = var2_bis + 2048
                        ADC8ValueRack1.delete(0, END)
                        ADC8ValueRack1.insert(0, (float(data[7]) * 5 / 1024))
                        if AuxPTOValveOn == 1:
                            # if (float(data[7]) * 5 /1024) > 2:
                            buffer[2] = (float(data[7]) * 5 / 1024)
                            var2_bis = var2_bis + 512
                    if j == 14:
                        ADC9ValueRack1.delete(0, END)
                        ADC9ValueRack1.insert(0, (float(data[0]) * 5 / 1024))
                        if (float(data[0]) * 5 / 1024) > 0.1:
                            buffer[3] = (float(data[0]) * 5 / 1024)
                            var2_bis = var2_bis + 32768
                        else:
                            buffer[3] == 0
                        ADC10ValueRack1.delete(0, END)
                        ADC10ValueRack1.insert(0, (float(data[1]) * 5 / 1024))
                        if (float(data[1]) * 5 / 1024) > 2:
                            var3_bis = var3_bis + 1
                        ADC11ValueRack1.delete(0, END)
                        ADC11ValueRack1.insert(0, (float(data[2]) * 5 / 1024))
                        if (float(data[2]) * 5 / 1024) > 2:
                            var3_bis = var3_bis + 64
                        ADC12ValueRack1.delete(0, END)
                        ADC12ValueRack1.insert(0, (float(data[3]) * 5 / 1024))
                        if (float(data[3]) * 5 / 1024) > 2:
                            var3_bis = var3_bis + 256
                        ADC13ValueRack1.delete(0, END)
                        ADC13ValueRack1.insert(0, (float(data[4]) * 5 / 1024))
                        if (float(data[4]) * 5 / 1024) > 2:
                            var3_bis = var3_bis + 4096
                        ADC14ValueRack1.delete(0, END)
                        ADC14ValueRack1.insert(0, (float(data[5]) * 5 / 1024))
                        if (float(data[5]) * 5 / 1024) > 2:
                            var3_bis = var3_bis + 512
                        ADC15ValueRack1.delete(0, END)
                        ADC15ValueRack1.insert(0, (float(data[6]) * 5 / 1024))
                        if (float(data[6]) * 5 / 1024) > 2:
                            var1_bis = var1_bis + 4
                        ADC16ValueRack1.delete(0, END)
                        ADC16ValueRack1.insert(0, (float(data[7]) * 5 / 1024))
                        if (float(data[7]) * 5 / 1024) > 2:
                            var3_bis = var3_bis + 2
                    if j == 15:
                        ADC17ValueRack1.delete(0, END)
                        ADC17ValueRack1.insert(0, (float(data[0]) * 5 / 1024))
                        if (float(data[0]) * 5 / 1024) > 2:
                            var3_bis = var3_bis + 32
                        ADC18ValueRack1.delete(0, END)
                        ADC18ValueRack1.insert(0, (float(data[1]) * 5 / 1024))
                        if (float(data[1]) * 5 / 1024) > 2:
                            var3_bis = var3_bis + 512
                        ADC19ValueRack1.delete(0, END)
                        ADC19ValueRack1.insert(0, (float(data[2]) * 5 / 1024))
                        if (float(data[2]) * 5 / 1024) > 2:
                            var4_bis = var4_bis + 8
                        ADC20ValueRack1.delete(0, END)
                        ADC20ValueRack1.insert(0, (float(data[3]) * 5 / 1024))
                        if RotorIncr == 1:
                            if (float(data[3]) * 5 / 1024) > 0.93:
                                buffer[4] = float(data[3]) * 5 / 1024
                                var4_bis = var4_bis + 32
                                # print('Var4_bis = ', var4_bis)
                            else:
                                buffer[4] = 0
                        ADC21ValueRack1.delete(0, END)
                        ADC21ValueRack1.insert(0, (float(data[4]) * 5 / 1024))
                        if RotorDecr == 1:
                            if (float(data[4]) * 5 / 1024) > 0.93:
                                buffer[4] = float(data[4]) * 5 / 1024
                                var4_bis = var4_bis + 2048
                            else:
                                buffer[4] = 0
                        ADC22ValueRack1.delete(0, END)
                        ADC22ValueRack1.insert(0, (float(data[5]) * 5 / 1024))
                        if (float(data[5]) * 5 / 1024) > 2:
                            var6_bis = var6_bis + 1024
                        ADC23ValueRack1.delete(0, END)
                        ADC23ValueRack1.insert(0, (float(data[6]) * 5 / 1024))
                        if (float(data[6]) * 5 / 1024) > 2:
                            var6_bis = var6_bis + 256
                        ADC24ValueRack1.delete(0, END)
                        ADC24ValueRack1.insert(0, (float(data[7]) * 5 / 1024))
                        if (float(data[7]) * 5 / 1024) > 2:
                            var6_bis = var6_bis + 16384
                    if j == 16:
                        ADC25ValueRack1.delete(0, END)
                        ADC25ValueRack1.insert(0, (float(data[0]) * 5 / 1024))
                        if (float(data[0]) * 5 / 1024) > 2:
                            var6_bis = var6_bis + 4096
                        ADC26ValueRack1.delete(0, END)
                        ADC26ValueRack1.insert(0, (float(data[1]) * 5 / 1024))
                        if (float(data[1]) * 5 / 1024) > 2:
                            var6_bis = var6_bis + 8
                        ADC27ValueRack1.delete(0, END)
                        ADC27ValueRack1.insert(0, (float(data[2]) * 5 / 1024))
                        if (float(data[2]) * 5 / 1024) > 2:
                            var6_bis = var6_bis + 128
                        ADC28ValueRack1.delete(0, END)
                        ADC28ValueRack1.insert(0, (float(data[3]) * 5 / 1024))
                        if (float(data[3]) * 5 / 1024) > 2:
                            var6_bis = var6_bis + 32
                        ADC29ValueRack1.delete(0, END)
                        ADC29ValueRack1.insert(0, (float(data[4]) * 5 / 1024))
                        if LHSpreaderOn == 1:
                            # if (float(data[4]) * 5 /1024) > 2:
                            buffer[1] = float(data[4]) * 5 / 1024
                            var6_bis = var6_bis + 2048
                        ADC30ValueRack1.delete(0, END)
                        ADC30ValueRack1.insert(0, (float(data[5]) * 5 / 1024))
                        if RHSpreaderOn == 1:
                            # if (float(data[5]) * 5 /1024) > 2:
                            buffer[0] = float(data[5]) * 5 / 1024
                            var6_bis = var6_bis + 512
                        ADC31ValueRack1.delete(0, END)
                        ADC31ValueRack1.insert(0, (float(data[6]) * 5 / 1024))
                        if (float(data[6]) * 5 / 1024) > 2:
                            var6_bis = var6_bis + 32768
                        ADC32ValueRack1.delete(0, END)
                        ADC32ValueRack1.insert(0, (float(data[7]) * 5 / 1024))
                        if (float(data[7]) * 5 / 1024) > 2:
                            var6_bis = var6_bis + 8192
            if (Racknr == 2):
                data = [0, 0, 0, 0, 0, 0, 0, 0]
                for j in range(13, 17):
                    for i in range(0, 8):
                        data[i] = analogInput(Racknr, i, j)
                    if j == 13:
                        ADC1ValueRack2.delete(0, END)
                        ADC1ValueRack2.insert(0, (float(data[0]) * 5 / 1024))
                        if (float(data[0]) * 5 / 1024) > 2:
                            var7_bis = var7_bis + 1
                        ADC2ValueRack2.delete(0, END)
                        ADC2ValueRack2.insert(0, (float(data[1]) * 5 / 1024))
                        if (float(data[1]) * 5 / 1024) > 2:
                            var7_bis = var7_bis + 4
                        ADC3ValueRack2.delete(0, END)
                        ADC3ValueRack2.insert(0, (float(data[2]) * 5 / 1024))
                        if (float(data[2]) * 5 / 1024) > 2:
                            var7_bis = var7_bis + 1024
                        ADC4ValueRack2.delete(0, END)
                        ADC4ValueRack2.insert(0, (float(data[3]) * 5 / 1024))
                        if (float(data[3]) * 5 / 1024) > 2:
                            var7_bis = var7_bis + 4096
                        ADC5ValueRack2.delete(0, END)
                        ADC5ValueRack2.insert(0, (float(data[4]) * 5 / 1024))
                        if RotorClutchOn == 1:
                            if (float(data[4]) * 5 / 1024) > 0.84:
                                buffer[5] = float(data[4]) * 5 / 1024
                                var7_bis = var7_bis + 16384
                            else:
                                buffer[5] = 0
                        ADC6ValueRack2.delete(0, END)
                        ADC6ValueRack2.insert(0, (float(data[5]) * 5 / 1024))
                        if (float(data[5]) * 5 / 1024) > 2:
                            var8_bis = var8_bis + 4
                        ADC7ValueRack2.delete(0, END)
                        ADC7ValueRack2.insert(0, (float(data[6]) * 5 / 1024))
                        if (float(data[6]) * 5 / 1024) > 2:
                            var8_bis = var8_bis + 1
                        ADC8ValueRack2.delete(0, END)
                        ADC8ValueRack2.insert(0, (float(data[7]) * 5 / 1024))
                        if (float(data[7]) * 5 / 1024) > 2:
                            var8_bis = var8_bis + 64
                    if j == 14:
                        ADC9ValueRack2.delete(0, END)
                        ADC9ValueRack2.insert(0, (float(data[0]) * 5 / 1024))
                        if (float(data[0]) * 5 / 1024) > 2:
                            var7_bis = var7_bis + 8
                        ADC10ValueRack2.delete(0, END)
                        ADC10ValueRack2.insert(0, (float(data[1]) * 5 / 1024))
                        if (float(data[1]) * 5 / 1024) > 2:
                            var7_bis = var7_bis + 32
                        ADC11ValueRack2.delete(0, END)
                        ADC11ValueRack2.insert(0, (float(data[2]) * 5 / 1024))
                        if (float(data[2]) * 5 / 1024) > 2:
                            var7_bis = var7_bis + 512
                        ADC12ValueRack2.delete(0, END)
                        ADC12ValueRack2.insert(0, (float(data[3]) * 5 / 1024))
                        if (float(data[3]) * 5 / 1024) > 2:
                            var7_bis = var7_bis + 32768
                        ADC13ValueRack2.delete(0, END)
                        ADC13ValueRack2.insert(0, (float(data[4]) * 5 / 1024))
                        ADC14ValueRack2.delete(0, END)
                        ADC14ValueRack2.insert(0, (float(data[5]) * 5 / 1024))
                        if (float(data[5]) * 5 / 1024) > 2:
                            var5_bis = var5_bis + 1024
                        '''
                        ADC15ValueRack2.delete(0, END)
                        ADC15ValueRack2.insert(0, (float(data[6]) * 5 /1024))
                        ADC16ValueRack2.delete(0, END)
                        ADC16ValueRack2.insert(0, (float(data[7]) * 5 /1024))
                        '''
                    '''
                    if j == 15:
                        ADC17ValueRack2.delete(0, END)
                        ADC17ValueRack2.insert(0, (float(data[0]) * 5 /1024))
                        ADC18ValueRack2.delete(0, END)
                        ADC18ValueRack2.insert(0, (float(data[1]) * 5 /1024))
                        ADC19ValueRack2.delete(0, END)
                        ADC19ValueRack2.insert(0, (float(data[2]) * 5 /1024))
                        ADC20ValueRack2.delete(0, END)
                        ADC20ValueRack2.insert(0, (float(data[3]) * 5 /1024))
                        ADC21ValueRack2.delete(0, END)
                        ADC21ValueRack2.insert(0, (float(data[4]) * 5 /1024))
                        ADC22ValueRack2.delete(0, END)
                        ADC22ValueRack2.insert(0, (float(data[5]) * 5 /1024))
                        ADC23ValueRack2.delete(0, END)
                        ADC23ValueRack2.insert(0, (float(data[6]) * 5 /1024))
                        ADC24ValueRack2.delete(0, END)
                        ADC24ValueRack2.insert(0, (float(data[7]) * 5 /1024))
                    if j == 16:
                        ADC25ValueRack2.delete(0, END)
                        ADC25ValueRack2.insert(0, (float(data[0]) * 5 /1024))
                        ADC26ValueRack2.delete(0, END)
                        ADC26ValueRack2.insert(0, (float(data[1]) * 5 /1024))
                        ADC27ValueRack2.delete(0, END)
                        ADC27ValueRack2.insert(0, (float(data[2]) * 5 /1024))
                        ADC28ValueRack2.delete(0, END)
                        ADC28ValueRack2.insert(0, (float(data[3]) * 5 /1024))
                        ADC29ValueRack2.delete(0, END)
                        ADC29ValueRack2.insert(0, (float(data[4]) * 5 /1024))
                        ADC30ValueRack2.delete(0, END)
                        ADC30ValueRack2.insert(0, (float(data[5]) * 5 /1024))
                        ADC31ValueRack2.delete(0, END)
                        ADC31ValueRack2.insert(0, (float(data[6]) * 5 /1024))
                        ADC32ValueRack2.delete(0, END)
                        ADC32ValueRack2.insert(0, (float(data[7]) * 5 /1024))
                        '''
            '''
            if (Racknr == 3):
                data = [0,0,0,0,0,0,0,0]
                for j in range(13, 17):
                for i in range(0, 8):
                    data[i] = analogInput(Racknr, i, j)
                if j == 13:
                    ADC1ValueRack3.delete(0, END)
                    ADC1ValueRack3.insert(0, (float(data[0]) * 5 /1024))
                    ADC2ValueRack3.delete(0, END)
                    ADC2ValueRack3.insert(0, (float(data[1]) * 5 /1024))
                    ADC3ValueRack3.delete(0, END)
                    ADC3ValueRack3.insert(0, (float(data[2]) * 5 /1024))
                    ADC4ValueRack3.delete(0, END)
                    ADC4ValueRack3.insert(0, (float(data[3]) * 5 /1024))
                    ADC5ValueRack3.delete(0, END)
                    ADC5ValueRack3.insert(0, (float(data[4]) * 5 /1024))
                    ADC6ValueRack3.delete(0, END)
                    ADC6ValueRack3.insert(0, (float(data[5]) * 5 /1024))
                    ADC7ValueRack3.delete(0, END)
                    ADC7ValueRack3.insert(0, (float(data[6]) * 5 /1024))
                    ADC8ValueRack3.delete(0, END)
                    ADC8ValueRack3.insert(0, (float(data[7]) * 5 /1024))
                if j == 14:
                    ADC9ValueRack3.delete(0, END)
                    ADC9ValueRack3.insert(0, (float(data[0]) * 5 /1024))
                    ADC10ValueRack3.delete(0, END)
                    ADC10ValueRack3.insert(0, (float(data[1]) * 5 /1024))
                    ADC11ValueRack3.delete(0, END)
                    ADC11ValueRack3.insert(0, (float(data[2]) * 5 /1024))
                    ADC12ValueRack3.delete(0, END)
                    ADC12ValueRack3.insert(0, (float(data[3]) * 5 /1024))
                    ADC13ValueRack3.delete(0, END)
                    ADC13ValueRack3.insert(0, (float(data[4]) * 5 /1024))
                    ADC14ValueRack3.delete(0, END)
                    ADC14ValueRack3.insert(0, (float(data[5]) * 5 /1024))
                    ADC15ValueRack3.delete(0, END)
                    ADC15ValueRack3.insert(0, (float(data[6]) * 5 /1024))
                    ADC16ValueRack3.delete(0, END)
                    ADC16ValueRack3.insert(0, (float(data[7]) * 5 /1024))
                if j == 15:
                    ADC17ValueRack3.delete(0, END)
                    ADC17ValueRack3.insert(0, (float(data[0]) * 5 /1024))
                    ADC18ValueRack3.delete(0, END)
                    ADC18ValueRack3.insert(0, (float(data[1]) * 5 /1024))
                    ADC19ValueRack3.delete(0, END)
                    ADC19ValueRack3.insert(0, (float(data[2]) * 5 /1024))
                    ADC20ValueRack3.delete(0, END)
                    ADC20ValueRack3.insert(0, (float(data[3]) * 5 /1024))
                    ADC21ValueRack3.delete(0, END)
                    ADC21ValueRack3.insert(0, (float(data[4]) * 5 /1024))
                    ADC22ValueRack3.delete(0, END)
                    ADC22ValueRack3.insert(0, (float(data[5]) * 5 /1024))
                    ADC23ValueRack3.delete(0, END)
                    ADC23ValueRack3.insert(0, (float(data[6]) * 5 /1024))
                    ADC24ValueRack3.delete(0, END)
                    ADC24ValueRack3.insert(0, (float(data[7]) * 5 /1024))
                if j == 16:
                    ADC25ValueRack3.delete(0, END)
                    ADC25ValueRack3.insert(0, (float(data[0]) * 5 /1024))
                    ADC26ValueRack3.delete(0, END)
                    ADC26ValueRack3.insert(0, (float(data[1]) * 5 /1024))
                    ADC27ValueRack3.delete(0, END)
                    ADC27ValueRack3.insert(0, (float(data[2]) * 5 /1024))
                    ADC28ValueRack3.delete(0, END)
                    ADC28ValueRack3.insert(0, (float(data[3]) * 5 /1024))
                    ADC29ValueRack3.delete(0, END)
                    ADC29ValueRack3.insert(0, (float(data[4]) * 5 /1024))
                    ADC30ValueRack3.delete(0, END)
                    ADC30ValueRack3.insert(0, (float(data[5]) * 5 /1024))
                    ADC31ValueRack3.delete(0, END)
                    ADC31ValueRack3.insert(0, (float(data[6]) * 5 /1024))
                    ADC32ValueRack3.delete(0, END)
                    ADC32ValueRack3.insert(0, (float(data[7]) * 5 /1024))'''


    def inputvariables_fn(self, Racknr, address):
        global var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12
        global var1_bis, var2_bis, var3_bis, var4_bis, var5_bis, var6_bis, var7_bis, var8_bis, var9_bis

        if (Racknr == 1):
            if address == 0x20:
                Rack1answer1 = (i2cbusRack1.read_word_data(address, 1)) ^ 0xFFFF
                # firstbyte1 = (answer1 & 0x00FF) ^ 0xFF
                # secondbyte1 = ((answer1 & 0xFF00) >> 8) ^ 0xFF
                Rack1answer1 = Rack1answer1 + var1_bis
                if Rack1answer1 != var1:
                    btnClick1(Rack1answer1)
                    var1 = Rack1answer1
            if address == 0x21:
                Rack1answer2 = (i2cbusRack1.read_word_data(address, 1)) ^ 0xFFFF
                # firstbyte2 = (answer2 & 0x00FF) ^ 0xFF
                # secondbyte2 = ((answer2 & 0xFF00) >> 8) ^ 0xFF
                Rack1answer2 = Rack1answer2 + var2_bis
                if Rack1answer2 != var2:
                    btnClick2(Rack1answer2)
                    var2 = Rack1answer2
            if address == 0x22:
                Rack1answer3 = (i2cbusRack1.read_word_data(address, 1)) ^ 0xFFFF
                # firstbyte3 = (answer3 & 0x00FF) ^ 0xFF
                # secondbyte3 = ((answer3 & 0xFF00) >> 8) ^ 0xFF
                Rack1answer3 = Rack1answer3 + var3_bis
                if Rack1answer3 != var3:
                    btnClick3(Rack1answer3)
                    var3 = Rack1answer3
            if address == 0x23:
                Rack1answer4 = (i2cbusRack1.read_word_data(address, 1)) ^ 0xFFFF
                if Rack1answer4 & 32 == 32:
                    Rack1answer4 -= 32
                # firstbyte4 = (answer4 & 0x00FF) ^ 0xFF
                # secondbyte4 = ((answer4 & 0xFF00) >> 8) ^ 0xFF
                Rack1answer4 = Rack1answer4 + var4_bis
                if Rack1answer4 != var4:
                    btnClick4(Rack1answer4)
                    var4 = Rack1answer4
        if (Racknr == 2):
            if address == 0x20:
                Rack2answer1 = (i2cbusRack2.read_word_data(address, 1)) ^ 0xFFFF
                # firstbyte1 = (answer1 & 0x00FF) ^ 0xFF
                # secondbyte1 = ((answer1 & 0xFF00) >> 8) ^ 0xFF
                Rack2answer1 = Rack2answer1 + var5_bis
                if Rack2answer1 != var5:
                    btnClick5(Rack2answer1)
                    var5 = Rack2answer1
            if address == 0x21:
                Rack2answer2 = (i2cbusRack2.read_word_data(address, 1)) ^ 0xFFFF
                # firstbyte2 = (answer2 & 0x00FF) ^ 0xFF
                # secondbyte2 = ((answer2 & 0xFF00) >> 8) ^ 0xFF
                Rack2answer2 = Rack2answer2 + var6_bis
                if Rack2answer2 != var6:
                    btnClick6(Rack2answer2)
                    var6 = Rack2answer2
            if address == 0x22:
                Rack2answer3 = (i2cbusRack2.read_word_data(address, 1)) ^ 0xFFFF
                # firstbyte3 = (answer3 & 0x00FF) ^ 0xFF
                # secondbyte3 = ((answer3 & 0xFF00) >> 8) ^ 0xFF
                Rack2answer3 = Rack2answer3 + var7_bis
                if Rack2answer3 != var7:
                    btnClick7(Rack2answer3)
                    var7 = Rack2answer3
            if address == 0x23:
                Rack2answer4 = (i2cbusRack2.read_word_data(address, 1)) ^ 0xFFFF
                # firstbyte4 = (answer4 & 0x00FF) ^ 0xFF
                # secondbyte4 = ((answer4 & 0xFF00) >> 8) ^ 0xFF
                Rack2answer4 = Rack2answer4 + var8_bis
                if Rack2answer4 != var8:
                    btnClick8(Rack2answer4)
                    var8 = Rack2answer4

        if (Racknr == 3):
            if address == 0x20:
                Rack3answer1 = (i2cbusRack3.read_word_data(address, 1)) ^ 0xFFFF
                # firstbyte1 = (answer1 & 0x00FF) ^ 0xFF
                # secondbyte1 = ((answer1 & 0xFF00) >> 8) ^ 0xFF
                Rack3answer1 = Rack3answer1 + var9_bis
                if Rack3answer1 != var9:
                    btnClick5(Rack3answer1)
                    var9 = Rack3answer1
            if address == 0x21:
                Rack3answer2 = (i2cbusRack3.read_word_data(address, 1)) ^ 0xFFFF
                # firstbyte2 = (answer2 & 0x00FF) ^ 0xFF
                # secondbyte2 = ((answer2 & 0xFF00) >> 8) ^ 0xFF
                if Rack3answer2 != var10:
                    btnClick6(Rack3answer2)
                    var10 = Rack3answer2
            if address == 0x22:
                Rack3answer3 = (i2cbusRack3.read_word_data(address, 1)) ^ 0xFFFF
                # firstbyte3 = (answer3 & 0x00FF) ^ 0xFF
                # secondbyte3 = ((answer3 & 0xFF00) >> 8) ^ 0xFF
                if Rack3answer3 != var11:
                    btnClick7(Rack3answer3)
                    var11 = Rack3answer3
            if address == 0x23:
                Rack3answer4 = (i2cbusRack3.read_word_data(address, 1)) ^ 0xFFFF
                # firstbyte4 = (answer4 & 0x00FF) ^ 0xFF
                # secondbyte4 = ((answer4 & 0xFF00) >> 8) ^ 0xFF
                if Rack3answer4 != var12:
                    btnClick8(Rack3answer4)
                    var12 = Rack3answer4

    def writei2cbus2bytes_fn(self, Racknr, address, value1, value2):
        # test purpose code
        print("\n Racknr : ", Racknr, "\n address : ", address, "\n value1 : ", value1, "\n value2 : ", value2)

        if (Racknr == 1):
            i2cbusRack1.write_word_data(address, value1, value2)
            print("Data written Racknr 1")
        if (Racknr == 2):
            i2cbusRack2.write_word_data(address, value1, value2)
            print("Data written Racknr 2")
        if (Racknr == 3):
            i2cbusRack3.write_word_data(address, value1, value2)
            print("Data written Racknr 3")