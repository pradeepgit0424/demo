/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

/* Modules */
import { LayoutModule } from '../layout/layout.module';

/* Components */
import * as outdoorComponents from './components';

/* Containers */
import * as outdoorContainers from './containers';

/* Guards */
import * as outdoorGuards from './guards';

/* Services */
import * as outdoorServices from './services';


@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        NgSelectModule,
        ReactiveFormsModule,
        FormsModule,
        LayoutModule,
        NgbModule
    ],
    providers: [...outdoorServices.services, ...outdoorGuards.guards],
    declarations: [...outdoorContainers.containers, ...outdoorComponents.components],
    exports: [...outdoorContainers.containers, ...outdoorComponents.components],
})
export class OutdoorModule { }
