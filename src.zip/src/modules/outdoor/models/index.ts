export * from './outdoor.model';
