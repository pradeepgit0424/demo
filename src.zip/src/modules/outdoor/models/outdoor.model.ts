export class LocationDetail {
    locationId: number;
    locationName: string;
    centerLat: number;
    centerLng: number;
    zoom: number;
    searchedLocation: string;
    searchedLocationLat: number;
    searchedLocationLng: number;
    drawings: DrawingDetail[];
}

export class DrawingDetail {
    drawingId: number;
    drawingName: string;
    type: string;
    coOrdinates: string;
    drawingShapeRef: any
}

export class AssetDetail {
    assetId: number;
    assetEui: string;
    assetName: string;
    assettype: string;
    currentAssetLat: number;
    currentAssetLng: number;
    locationId: number;
    lastUpdated: string;
    battery: number;
    assetRef: any
}
