/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

/* Module */
import { OutdoorModule } from './outdoor.module';

/* Containers */
import * as outdoorContainers from './containers';

/* Guards */
import * as outdoorGuards from './guards';

/* Routes */
export const ROUTES: Routes = [
    {
        path: '',
        canActivate: [],
        component: outdoorContainers.OutdoorComponent,
    }
];

@NgModule({
    imports: [OutdoorModule, RouterModule.forChild(ROUTES)],
    exports: [RouterModule],
})
export class OutdoorRoutingModule {}
