import { OutdoorGuard } from './outdoor.guard';

export const guards = [OutdoorGuard];

export * from './outdoor.guard';
