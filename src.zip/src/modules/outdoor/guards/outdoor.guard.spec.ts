import { TestBed } from '@angular/core/testing';

import { OutdoorGuard } from './outdoor.guard';

describe('OutdoorGuard', () => {
  let guard: OutdoorGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(OutdoorGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
