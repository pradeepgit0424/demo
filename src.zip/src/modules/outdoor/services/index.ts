import { OutdoorService } from './outdoor.service';

export const services = [OutdoorService];

export * from './outdoor.service';
