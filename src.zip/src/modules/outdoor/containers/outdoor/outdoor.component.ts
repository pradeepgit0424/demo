import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-outdoor',
  templateUrl: './outdoor.component.html',
  styleUrls: ['./outdoor.component.css']
})
export class OutdoorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
