import { OutdoorComponent} from './outdoor/outdoor.component';

export const containers = [OutdoorComponent];

export * from './outdoor/outdoor.component';

