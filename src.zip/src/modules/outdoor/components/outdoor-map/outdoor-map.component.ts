import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, OnDestroy } from '@angular/core';
import { Observable } from 'rxjs';
import { debounceTime, map } from 'rxjs/operators';

import { } from 'googlemaps';
import { OutdoorService } from '../../services';
import { LocationDetail, DrawingDetail, AssetDetail } from '../../models';

@Component({
  selector: 'app-outdoor-map',
  templateUrl: './outdoor-map.component.html',
  styleUrls: ['./outdoor-map.component.css']
})
export class OutdoorMapComponent implements OnInit,AfterViewInit,OnDestroy {

  @ViewChild('mapContainer', { static: false }) mapElement: ElementRef;
  map: google.maps.Map;

  //  Variable to hold the selected Location Type
  selectedlocationId: number;
  //  Variable to hold the Asset Name
  selectedAssetsName: string;
  isSearchAllAssetsSelected = false;
  locationLstHardcode = [];
  selectedlocationIdHardcode: any;
  locationsLst: LocationDetail[];
  assetLst: AssetDetail[];
  assetSelected: AssetDetail;


  constructor(private outdoorService: OutdoorService) {
    // customize default values of typeaheads used by this component tree

  }

  ngOnInit() {
    //this.getAllLocations();
    this.getMapLocationList();
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.initMap();
    }, 1000);
    
  }

  ngOnDestroy() {
    this.map.unbindAll();
  }

  // Function to get all the countries from the Server
  getAllLocations() {
    this.outdoorService.getAllLocations().subscribe(res => {
      this.locationsLst = res;
    });
  }

   getMapLocationList() {
     // this.selectedlocationIdHardcode = mysoreJSON[0].locationName;
      for (var i = 0; i < mysoreJSON.length; i++) {
        var locationName = mysoreJSON[i].locationName;
        this.locationLstHardcode.push(locationName);
      }
    } 
   
  

  // Hard code functio of change location
 // Function to Change Location
 onChangeLocationHardCode(selectedLocation: any) {
      //console.log(selectedLocation);
      var jsonData;
      for (var i = 0; i < mysoreJSON.length; i++) {
        if (selectedLocation == mysoreJSON[i].locationName) {
          jsonData = mysoreJSON[i];
        }
      }
      // Declaring variables
      var map: any;
      // Creating Map and its Properties
      map = new google.maps.Map(
        document.getElementById('map'), {
        zoom: jsonData.zoom,
        center: new google.maps.LatLng(jsonData.centerLat, jsonData.centerLng),
        mapTypeId: 'roadmap',
        mapTypeControl: true,
        mapTypeControlOptions: {
          style: google.maps.MapTypeControlStyle.DEFAULT,
          position: google.maps.ControlPosition.TOP_LEFT
        }
      });
  
      var markers = [];
      // Create a marker for each Searched Place.
      markers.push(new google.maps.Marker({
        map: map,
        icon: 'assets/images/green_point.png',
        title: jsonData.searchedLocation,
        position: { lat: jsonData.searchedLocationLat, lng: jsonData.searchedLocationLng }
      }));
  
      // Drawing Marker
      markers.push(new google.maps.Marker({
        map: map,
        icon: 'assets/images/location.png',
        title: 'Marker',
        position: { lat: jsonData.drawings[0].lat, lng: jsonData.drawings[0].lng }
      }));
  
      // Drawing Circles
      var circles = [];
  
      circles.push(new google.maps.Circle({
        strokeOpacity: 0.8,
        strokeWeight: 2,
        fillColor: '#ff0000',
        fillOpacity: 0.5,
        map: map,
        center: {
          lat: jsonData.centerLat, lng: jsonData.centerLng
        },
        //center: { lat: mysoreJSON[0].drawings[1].circleLat, lng: mysoreJSON[0].drawings[1].circleLng },
        radius: jsonData.drawings[1].radius
      }));
  
      // Drawing Rectangles
      var rectangles = [];
  
      rectangles.push(new google.maps.Rectangle({
        strokeColor: '#FF0000',
        strokeOpacity: 0.8,
        strokeWeight: 2,
        fillColor: '#FF0000',
        fillOpacity: 0.35,
        map: map,
        bounds: {
          north: jsonData.drawings[2].bounds.north,
          south: jsonData.drawings[2].bounds.south,
          east: jsonData.drawings[2].bounds.east,
          west: jsonData.drawings[2].bounds.west,
        }
      }));
    } 

  getAllAssetByLocation(locationId: number) {
    this.outdoorService.getAllAssetsByLocation(locationId).subscribe(res => {
      this.assetLst = res;
    });
  }

  //Map Initialization
  initMap() {
    this.map = new google.maps.Map(document.getElementById('map'), {
      zoom: 3,
      center: new google.maps.LatLng(12.97159, 77.59456),
      mapTypeId: 'roadmap',
      mapTypeControl: true,
      mapTypeControlOptions: {
        position: google.maps.ControlPosition.TOP_RIGHT
      }
    });
  }
  
  // Function to Change Location
  onChangeLocation() {
    let selectedLocationDetails = this.locationsLst.filter(location => location.locationId === this.selectedlocationId)[0];
    if (selectedLocationDetails) {
      this.getAllAssetByLocation(selectedLocationDetails.locationId);
      this.map.setCenter(new google.maps.LatLng(selectedLocationDetails.centerLat, selectedLocationDetails.centerLng));
      this.map.setZoom(selectedLocationDetails.zoom);
      if (selectedLocationDetails.searchedLocation) {
        new google.maps.Marker({
          map: this.map,
          icon: 'assets/images/green_point.png',
          title: selectedLocationDetails.searchedLocation,
          position: { lat: selectedLocationDetails.searchedLocationLat, lng: selectedLocationDetails.searchedLocationLng }
        })

      }

      selectedLocationDetails.drawings.forEach(drawing => {
        switch (drawing.type) {
          case 'marker':
            this.addMarkerToMap(drawing);
            break;
          case 'circle':
            this.addCircleToMap(drawing);
            break;
          case 'polygon':
            this.addPolygonToMap(drawing);
            break;
          case 'rectangle':
            this.addRectangleToMap(drawing);
            break;
        }
      });
    }
  }


  addMarkerToMap(marker: DrawingDetail) {
    marker.drawingShapeRef = new google.maps.Marker({
      map: this.map,
      icon: 'assets/images/assetGreen.png',
      title: marker.drawingName,
      position: { lat: +marker.coOrdinates.split(',')[0], lng: +marker.coOrdinates.split(',')[1] }
    })
  }

  addAssetMarkerToMap(marker: AssetDetail, timeout: number) {
    window.setTimeout(() => {
      marker.assetRef = new google.maps.Marker({
        map: this.map,
        icon: 'assets/images/assetRed.png',
        title: marker.assetEui,
        animation: google.maps.Animation.DROP,
        position: { lat: marker.currentAssetLat, lng: marker.currentAssetLng }
      })
    }, timeout);

  }


  addCircleToMap(circle: DrawingDetail) {
    let circleValues = circle.coOrdinates.split(';');
    let centerVal = circleValues[0];
    let radiusVal = circleValues[1];
    circle.drawingShapeRef = new google.maps.Circle({
      strokeColor: '#33cc00',
      strokeOpacity: 0.5,
      strokeWeight: 0.5,
      fillColor: '#33cc00',
      fillOpacity: 0.1,
      map: this.map,
      center: { lat: +centerVal.split(',')[0], lng: +centerVal.split(',')[1] },
      radius: +radiusVal
    });
  }

  addPolygonToMap(polygon: DrawingDetail) {
    let coords = [];
    let polygonCoords = polygon.coOrdinates.split(';');
    polygonCoords.pop();
    polygonCoords.forEach(cord => {
      coords.push({ lat: +cord.split(',')[0], lng: +cord.split(',')[1] })
    });
    coords.push({ lat: +polygonCoords[0].split(',')[0], lng: +polygonCoords[0].split(',')[1] })
    // Construct the polygon.
    polygon.drawingShapeRef = new google.maps.Polygon({
      paths: coords,
      strokeColor: '#0000cc',
      strokeOpacity: 0.5,
      strokeWeight: 0.5,
      fillColor: '#0000cc',
      fillOpacity: 0.1
    });
    polygon.drawingShapeRef.setMap(this.map);
  }

  addRectangleToMap(rect: DrawingDetail) {
    let boundsVal = rect.coOrdinates.split(',');
    console.log(boundsVal)
    rect.drawingShapeRef = new google.maps.Rectangle({
      strokeColor: '#FF0000',
      strokeOpacity: 0.5,
      strokeWeight: 0.5,
      fillColor: '#FF0000',
      fillOpacity: 0.1,
      map: this.map,
      bounds: {
        south: +boundsVal[0],
        west: +boundsVal[1],
        north: +boundsVal[2],
        east: +boundsVal[3]
      }
    });
  }

  clearAsset() {
    let assetDetail = this.assetLst.filter(asset => asset.assetEui === this.assetSelected.assetEui);
    if (assetDetail && assetDetail.length > 0) {
      assetDetail[0].assetRef.setMap(null);
      assetDetail[0].assetRef = null;
    }
    this.assetSelected = null;
  }

  search = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      map(term => term === '' ? []
        : this.assetLst.filter(v => v.assetEui.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10))
    )

  formatter = (x: { assetEui: string }) => x.assetEui;


  assetOnSelected(asset: any) {
    this.clearAllAssetsOnMap();
    this.addAssetMarkerToMap(asset.item, 200);
  }

  loadAllAssetsOnMap() {
    if (this.selectedlocationId) {
      this.clearAllAssetsOnMap();
      this.isSearchAllAssetsSelected = true;
      this.assetLst.forEach((asset, index) => {
        if (!asset.assetRef) {
          this.addAssetMarkerToMap(asset, index * 200)
        }
      });
    }

  }


  clearAllAssetsOnMap() {
    this.isSearchAllAssetsSelected = false;
    this.assetLst.forEach(asset => {
      if (asset.assetRef) {
        asset.assetRef.setMap(null);
        asset.assetRef = null;
      }
    });
  }
}

//JSON Data
var mysoreJSON = [
    {
      locationId: 1,
      locationName: "LTTS Mysore",
      centerLat: 12.356496,
      centerLng: 76.594055,
      zoom: 17,
      searchedLocation: "L&T Technology Services",
      searchedLocationLat: 12.3572581,
      searchedLocationLng: 76.5947807,
      drawings: [
        {
          type: "marker",
          lat: 12.356854,
          lng: 76.59231
        },
        {
          type: "circle",
          circleLat: 12.357918,
          circleLng: 76.59334,
          radius: 42.4669178088449
        },
        {
          type: "rectangle",
          bounds: {
            north: 12.356786,
            south: 12.356314,
            east: 76.594091,
            west: 76.59319
          }
        }
      ]
    },
    {
      locationId: 2,
      locationName: "LTTS Vadodara",
      centerLat: 22.307112,
      centerLng: 73.255398,
      zoom: 17,
      searchedLocation: "L&T Knowledge City",
      searchedLocationLat: 22.307016,
      searchedLocationLng: 73.254717,
      drawings: [
        {
          type: "marker",
          lat: 22.307921,
          lng: 73.255902
        },
        {
          type: "circle",
          circleLat: 22.307395,
          circleLng: 73.256804,
          radius: 47.56407581260802
        },
        {
          type: "rectangle",
          bounds: {
            //22.306174,73.256482,22.30665,73.257351
            north: 22.306174,
            south: 22.30665,
            east: 73.257351,
            west: 73.256482
          }
        }
      ]
    },
    {
      locationId: 3,
      locationName: "LTTS Bangalore",
      centerLat: 13.043488,
      centerLng: 77.618666,
      zoom: 17,
      searchedLocation: "L&T Manyata Tech Park",
      searchedLocationLat: 13.045069,
      searchedLocationLng: 77.618947,
      drawings: [
        {
          type: "marker",
          lat: 13.045186,
          lng: 77.618279
        },
        {
          type: "circle",
          circleLat: 13.044642,
          circleLng: 77.620779,
          radius: 29.663768755365805
        },
        {
          type: "rectangle",
          bounds: {
            //NWSE
            //13.042792,77.619138,13.043492,77.620404
            north: 13.042792,
            south: 13.043492,
            east: 77.620404,
            west: 77.619138
          }
        }
      ]
    }
  ]; 
