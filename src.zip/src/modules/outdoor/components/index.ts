import {OutdoorMapComponent} from './outdoor-map/outdoor-map.component';
export const components = [
    OutdoorMapComponent
];
export * from './outdoor-map/outdoor-map.component';


