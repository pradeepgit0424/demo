import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
//import { IndoorRoutingModule } from './indoor-routing.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
//import { IndoorCardsComponent } from './indoor-cards/indoor-cards.component';
//import { IndoorComponent } from './containers/indoor/indoor.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';



/* Modules */
import { LayoutModule } from '../layout/layout.module';

/* Components */
import * as indoorComponents from './components';

/* Containers */
import * as indoorContainers from './containers';
import { PaintingComponent } from './components/painting/painting.component';

/* Guards */
//import * as outdoorGuards from './guards';

/* Services */
//import * as outdoorServices from './services';


@NgModule({
  //declarations: [IndoorCardsComponent, IndoorComponent],
  imports: [
    CommonModule,
    RouterModule,
    NgSelectModule,
    ReactiveFormsModule,
    FormsModule,
    LayoutModule,
   // IndoorRoutingModule,
    NgbModule
  ],
  //providers: [...indoorServices.services, ...indoorGuards.guards],
  declarations: [...indoorContainers.containers, ...indoorComponents.components, PaintingComponent],
  exports: [...indoorContainers.containers, ...indoorComponents.components],

})
export class IndoorModule { }
