// import { IndoorGuard } from './indoor.guard';

// export const guards = [IndoorGuard];

// export * from './indoor.guard';
