import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

/* Module */
import { IndoorModule } from './indoor.module';

/* Containers */
import * as indoorContainers from './containers';

import * as indoorComponents from './components';


/* Guards */
//import * as indoorGuards from './guards';


/* Routes */
export const ROUTES: Routes = [
  {
      path: '',
      canActivate: [],
      component: indoorContainers.IndoorComponent,
      children: [
        {
            path: 'painting',
            canActivate: [],
            component: indoorComponents.PaintingComponent
        },
        {
          path: 'list',
          canActivate: [],
          component: indoorComponents.IndoorCardsComponent
      },
      {
          path:'',
          redirectTo:'list',
          pathMatch:'full'
      }
      ]
  }
];

@NgModule({
  imports: [IndoorModule,RouterModule.forChild(ROUTES)],
  exports: [RouterModule]
})
export class IndoorRoutingModule { }
