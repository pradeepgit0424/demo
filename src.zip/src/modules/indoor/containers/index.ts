import { IndoorComponent} from './indoor/indoor.component';

export const containers = [IndoorComponent];

export * from './indoor/indoor.component';

