import {IndoorCardsComponent} from './indoor-cards/indoor-cards.component';
import {PaintingComponent} from './painting/painting.component';

export const components = [
    IndoorCardsComponent,
    PaintingComponent
];
export * from './indoor-cards/indoor-cards.component';
export * from './painting/painting.component';



