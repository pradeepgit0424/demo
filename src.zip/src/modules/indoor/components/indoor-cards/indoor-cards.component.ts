import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indoor-cards',
  templateUrl: './indoor-cards.component.html',
  styleUrls: ['./indoor-cards.component.css']
})
export class IndoorCardsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
