import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndoorCardsComponent } from './indoor-cards.component';

describe('IndoorCardsComponent', () => {
  let component: IndoorCardsComponent;
  let fixture: ComponentFixture<IndoorCardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndoorCardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndoorCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
