import { LayoutGuard } from './layout.guard';

export const guards = [LayoutGuard];

export * from './layout.guard';
