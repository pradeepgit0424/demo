/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

/* Modules */


/* Components */
import * as layoutComponents from './components';

/* Containers */
import * as layoutContainers from './containers';

/* Guards */
import * as layoutGuards from './guards';

/* Services */
import * as layoutServices from './services';



@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        ReactiveFormsModule,
        FormsModule
    ],
    providers: [...layoutServices.services, ...layoutGuards.guards],
    declarations: [...layoutContainers.containers, ...layoutComponents.components],
    exports: [...layoutContainers.containers, ...layoutComponents.components],
})
export class LayoutModule {}
