/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

/* Module */
import { LayoutModule } from './layout.module';

/* Containers */
import * as layoutContainers from './containers';

/* Guards */
import * as layoutGuards from './guards';

/* Routes */
export const ROUTES: Routes = [
    {
        path: '',
        canActivate: [],
        component: layoutContainers.LayoutComponent,
    }
];

@NgModule({
    imports: [LayoutModule, RouterModule.forChild(ROUTES)],
    exports: [RouterModule],
})
export class LayoutRoutingModule {}
