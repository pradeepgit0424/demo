import {LayoutHeaderComponent} from './layout-header/layout-header.component';
export const components = [
    LayoutHeaderComponent
];

export * from './layout-header/layout-header.component';

