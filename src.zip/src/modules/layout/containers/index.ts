import { LayoutComponent} from './layout/layout.component';

export const containers = [LayoutComponent];

export * from './layout/layout.component';

