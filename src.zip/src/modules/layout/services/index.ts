import { LayoutService } from './layout.service';

export const services = [LayoutService];

export * from './layout.service';
