import { AdminComponent} from './admin/admin.component';

export const containers = [AdminComponent];

export * from './admin/admin.component';

