/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';

/* Module */
import { AdminModule } from './admin.module';

/* Containers */
import * as adminContainers from './containers';

/* Components */
import * as adminComponents from './components';

/* Guards */
import * as adminGuards from './guards';

/* Routes */
export const ROUTES: Routes = [
    {
        path: '',
        canActivate: [],
        component: adminContainers.AdminComponent,
        children: [
            {
                path: 'manageOutdoor',
                canActivate: [],
                component: adminComponents.AdminOutdoorComponent
            },
            {
                path: 'manageIndoor',
                canActivate: [],
                component: adminComponents.AdminOutdoorComponent
            },
            {
                path: 'adminAssetLocation',
                canActivate: [],
                component: adminComponents.AdminAssetLocationComponent
            },
            {
                path: 'assetVehicleMapping',
                canActivate: [],
                component: adminComponents.AssetVehicleMappingComponent
            },
            {
                path: 'manageUsers',
                canActivate: [],
                component: adminComponents.ManageUsersComponent
            },

            {
                path:'',
                redirectTo:'outdoor',
                pathMatch:'full'
            }
        ]
    }
];

@NgModule({
    imports: [AdminModule, RouterModule.forChild(ROUTES)],
    exports: [RouterModule],
})
export class AdminRoutingModule {}
