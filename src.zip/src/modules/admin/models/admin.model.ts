export class LocationDetail{
    locationId:number;
    locationName:string;
    centerLat:number;
    centerLng:number;
    zoom:number;
    searchedLocation:string;
    searchedLocationLat:number;
    searchedLocationLng:number;
    searchedLocationRef : any;
    drawings:DrawingDetail[];
}

export class DrawingDetail{
    drawingId:number;
    drawingName:string;
    type:string;
    coOrdinates:string;
    drawingShapeRef:any
}

//Asset details for Asset
export class AssetDetail {
    assetId: number;
    assetEui: string;
    assetName: string;
    assettype: string;
    currentAssetLat: number;
    currentAssetLng: number;
    locationId: number;
    lastUpdated: string;
    battery: number;
    assetRef: any
}

//Mapping of asset with location
// export class AssetLocationMapping{
//     assetLocationMapId:number;
//     assetId: number;
//     locationId: number;
//     assets:AssetDetail[];
//     locations:LocationDetail[];
//   static locationId: any;
//   static assetId: any;
// }

export class AssetLocationMapping{
    locationName: any;
    locationId: number;
    assetIds:number[];
   
}



