import { TestBed } from '@angular/core/testing';

import { AdminOutdoorService } from './admin-outdoor.service';

describe('AdminOutdoorService', () => {
  let service: AdminOutdoorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdminOutdoorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
