import { AdminOutdoorService } from './admin-outdoor.service';

export const services = [AdminOutdoorService];

export * from './admin-outdoor.service';
