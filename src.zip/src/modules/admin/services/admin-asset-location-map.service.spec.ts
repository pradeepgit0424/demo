import { TestBed } from '@angular/core/testing';

import { AdminAssetLocationMapService } from './admin-asset-location-map.service';

describe('AdminAssetLocationMapService', () => {
  let service: AdminAssetLocationMapService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdminAssetLocationMapService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
