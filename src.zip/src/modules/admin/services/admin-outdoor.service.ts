import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import {LocationDetail} from '../models/admin.model';

// API base path
const API_URL = environment.apiUrl;

@Injectable({
  providedIn: 'root'
})



export class AdminOutdoorService {
  private locationUrl = API_URL + "/api/location";


  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
  constructor(private http: HttpClient) { }

  addLocation(location: LocationDetail): Observable<number> {
    return this.http.post<number>(this.locationUrl, location, this.httpOptions).pipe(
      tap((locationID) => this.log(`added Location w/ id=${locationID}`)),
      catchError(this.handleError<number>('add Location Failed'))
    );
  }

  /**
  * Handle Http operation that failed.
  * Let the app continue.
  * @param operation - name of the operation that failed
  * @param result - optional value to return as the observable result
  */
 private handleError<T>(operation = 'operation', result?: T) {
  return (error: any): Observable<T> => {

    // TODO: send the error to remote logging infrastructure
    console.error(error); // log to console instead

    // TODO: better job of transforming error for user consumption
    this.log(`${operation} failed: ${error.message}`);

    // Let the app keep running by returning an empty result.
    return of(result as T);
  };
}

/** Log a HeroService message with the MessageService */
private log(message: string) {
  console.log(`OutdoorService: ${message}`)
}
}
