import {AdminOutdoorComponent} from './admin-outdoor/admin-outdoor.component';
import {AdminAssetLocationComponent} from './admin-asset-location/admin-asset-location.component';
import {AssetVehicleMappingComponent} from './asset-vehicle-mapping/asset-vehicle-mapping.component';
import {ManageUsersComponent} from './manage-users/manage-users.component';
//import { from } from 'rxjs';
export const components = [
    AdminOutdoorComponent,
    AdminAssetLocationComponent,
    AssetVehicleMappingComponent,
    ManageUsersComponent
];

export * from './admin-outdoor/admin-outdoor.component';
export * from './admin-asset-location/admin-asset-location.component';
export * from './asset-vehicle-mapping/asset-vehicle-mapping.component';
export * from './manage-users/manage-users.component';


