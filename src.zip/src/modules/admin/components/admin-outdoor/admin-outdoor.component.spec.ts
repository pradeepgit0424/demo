import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminOutdoorComponent } from './admin-outdoor.component';

describe('AdminOutdoorComponent', () => {
  let component: AdminOutdoorComponent;
  let fixture: ComponentFixture<AdminOutdoorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminOutdoorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminOutdoorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
