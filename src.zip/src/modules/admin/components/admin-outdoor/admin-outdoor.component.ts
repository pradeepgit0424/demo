import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, OnDestroy } from '@angular/core';
import { } from 'googlemaps';
import { LocationDetail, DrawingDetail } from '../../models';
import { AdminOutdoorService } from '../../services';

@Component({
  selector: 'app-admin-outdoor',
  templateUrl: './admin-outdoor.component.html',
  styleUrls: ['./admin-outdoor.component.css']
})
export class AdminOutdoorComponent implements OnInit, AfterViewInit, OnDestroy {

  @ViewChild('mapContainer', { static: false }) mapElement: ElementRef;
  map: google.maps.Map;
  hideSearchBox = true;
  locationDetails: LocationDetail = new LocationDetail()
  selectedShape;
  input;
  newShape: any;
  content: any;
  newText: string;

  // Constructor of this Class
  constructor(private adminOutdoorService: AdminOutdoorService) { }

  ngOnInit() {
    this.locationDetails.drawings = [];
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.initMap();
      setTimeout(() => {
        this.hideSearchBox = false;
      }, 1000);
    }, 1000);
  }

  ngOnDestroy() {
    this.map.unbindAll();
  }

  initMap() {

    this.map = new google.maps.Map(
      document.getElementById('map'), { zoom: 3, center: new google.maps.LatLng(12.97159, 77.59456), mapTypeId: 'roadmap', mapTypeControl: false });

    let drawingManager = new google.maps.drawing.DrawingManager({
      drawingControl: true,
      drawingControlOptions: {
        position: google.maps.ControlPosition.TOP_LEFT,
        drawingModes: [google.maps.drawing.OverlayType.MARKER, google.maps.drawing.OverlayType.CIRCLE,
        google.maps.drawing.OverlayType.POLYGON, google.maps.drawing.OverlayType.RECTANGLE]
      },
      markerOptions: {
        draggable: true,
        icon: 'assets/images/green_point.png',
      },
      rectangleOptions: {
        strokeColor: '#FF0000',
        strokeOpacity: 0.5,
        strokeWeight: 0.5,
        fillColor: '#FF0000',
        fillOpacity: 0.5,
        editable: true
      },
      circleOptions: {
        strokeColor: '#33cc00',
        strokeOpacity: 0.5,
        strokeWeight: 0.5,
        fillColor: '#33cc00',
        fillOpacity: 0.5,
        editable: true
      },
      polygonOptions: {
        strokeColor: '#0000cc',
        strokeOpacity: 0.5,
        strokeWeight: 0.5,
        fillColor: '#0000cc',
        fillOpacity: 0.5,
        editable: true
      },
    });

    google.maps.event.addListener(drawingManager, 'overlaycomplete', (e) => {
      //~ if (e.type != google.maps.drawing.OverlayType.MARKER) {
      let isNotMarker = (e.type != google.maps.drawing.OverlayType.MARKER);
      // Switch back to non-drawing mode after drawing a shape.
      drawingManager.setDrawingMode(null);

      // Add an event listener that selects the newly-drawn shape when the user
      // mouses down on it.
      let newShape = e.overlay;
      newShape.type = e.type;
      newShape.id = Math.floor(Math.random() * 1000);
      let typeCount = this.locationDetails.drawings.filter(shape => shape.type === newShape.type).length + 1;
      let drawingShapeDetail = new DrawingDetail();
      drawingShapeDetail.drawingId = newShape.id;
      drawingShapeDetail.type = newShape.type;
      //drawingShapeDetail.drawingName = newShape.type + ' ' + typeCount + ' ' + infowindowBox();
      drawingShapeDetail.drawingShapeRef = newShape;
      this.locationDetails.drawings.push(drawingShapeDetail);

      var x;
      function nameShapes() {
        x = document.getElementById(identity);
        return x;
      }

      google.maps.event.addListener(newShape, 'click', () => {
        this.setSelection(newShape, isNotMarker);

      });
      google.maps.event.addListener(newShape, 'drag', () => {
        this.updateCurSelText(newShape);
      });
      google.maps.event.addListener(newShape, 'dragend', () => {
        this.updateCurSelText(newShape);
      });
      var identity = newShape.type + ' ' + typeCount;

      function BtnDone() {
        document.getElementById("drawingNameId").innerHTML = identity;
       // var box = document.createElement('input').setAttribute('id', identity)
        console.log("btn");
      }

      function infowindowBox() {
        var name = //'<form id="form'+identity+'"><div>'+
          '<input name="input' + identity + '"type = "text" value = "' + identity + '"/>' +
          '<button id="btn' + identity + ' (click)="' + BtnDone() + '">Submit</button>'
        //  '</div></form>'
        x = document.getElementById("form" + identity);
        console.log(x);
        return name;
      }

      var infowindow = new google.maps.InfoWindow({
        content: name
      });

      //let activeInfoWindow ; 
      google.maps.event.addListener(newShape, 'click', () => {
        // Set Content for infowindow
        infowindow.setContent(infowindowBox());
        // Open InfoWindow
        infowindow.open(this.map, newShape);
        //Conditions for shapes
        switch (newShape.type) {
          case "circle": infowindow.setPosition(newShape.getCenter()); break;
          case "rectangle": infowindow.setPosition(newShape.getBounds().getCenter());; break;
          case "polygon": infowindow.setPosition(newShape.getPath().getAt(0)); break;
        }
      });
      this.setSelection(newShape, isNotMarker);
    });

    //===================================================================================
    //let newText;
    // function  newText(a, thiis){ 
    //   var newText = prompt("Edit marker name", (thiis).html());
    //   this.newShape = window['newShape_'+a];
    //   if(newText){
    //     (thiis).html(newText);
    //     this.newShape.setTitle(newText);
    //     google.maps.event.clearListeners(this.newShape, 'click');
    //     this. content = `<span class='destination_name' onclick='newText(\\"${a}\\",thiis)'>${newText}</span>`;
    //     this. infowindow = new google.maps.InfoWindow();   
    //     google.maps.event.addListener(this.newShape,'click', (newShape, content, infowindow) =>{
    //     //   return function() {
    //     //     infowindow.setContent(content);
    //     //     infowindow.open(this.map, newShape);
    //     // };

    //   })
    //   ;(this.newShape ,this.content,this.infowindow);
    // }
    // }

    //   function fnGetNewTextForInfoWindow(){

    //     newText = document.getElementById('idSomeNewText');
    //   //   var inputBox = "<input type= 'text'/>"
    //   //  return add_fields();
    //    return newText.value;
    //  }

    //  var index = 0;
    //  function getUserName() {}
    //  function myfn(){
    //   //var d = add_fields().getElementsByTagName('input');
    //   //console.log(d);
    //   console.log(index)

    //   var subButton = document.getElementById('subButton');
    //   var nameField = document.getElementById('nameField');
    //  subButton.addEventListener('click', myfn, false);
    //   console.log(nameField)
    // }

    //  function add_fields() {

    //   index++;
    //   var divtest = document.createElement("div");
    //   divtest.innerHTML = 
    //   //("<input type='text' id='input"+index+"'>"+
    //  // "<button  id='btn"+index+" onclick='+"+myfn()+"'>add</button>");

    //   ("<form id='nameForm'>"+
    //   "<div class='form-uname'>"+
    //       "<label id='nameLable' for='nameField'>Create a username:</label>"+
    //       "<input id='nameField' type='text' maxlength='25'></input>"+
    //   "</div>"+
    //   "<div class='form-sub'>"+
    //       "<button id='subButton' type='button'>Print your name!</button>"+
    //   "</div>"+
    //   "</form>");
    //   return divtest;
    //   }
    //===================================================================================

    // Clear the current selection when the drawing mode is changed, or when the
    // map is clicked.
    google.maps.event.addListener(drawingManager, 'drawingmode_changed', this.clearSelection);
    google.maps.event.addListener(this.map, 'click', this.clearSelection);
    drawingManager.setMap(this.map);
    // // Create the search box and link it to the UI element.
    this.input = document.getElementById('pac-input');
    let searchBox = new google.maps.places.SearchBox(this.input);
    this.map.controls[google.maps.ControlPosition.TOP_LEFT].push(this.input);

    // Bias the SearchBox results towards current map's viewport.
    this.map.addListener('bounds_changed', () => {
      searchBox.setBounds(this.map.getBounds());
      this.locationDetails.centerLat = this.map.getCenter().lat();
      this.locationDetails.centerLng = this.map.getCenter().lng();
      this.locationDetails.zoom = this.map.getZoom();
      this.input.value = '';
    });

    let markers = [];
    // Listen for the event fired when the user selects a prediction and retrieve
    // more details for that place.
    searchBox.addListener('places_changed', () => {
      let places = searchBox.getPlaces();
      if (places.length == 0) {
        return;
      }
      // Clear out the old markers.
      markers.forEach((marker) => {
        marker.setMap(null);
      });
      markers = [];
      // For each place, get the icon, name and location.
      let bounds = new google.maps.LatLngBounds();
      places.forEach((place) => {
        if (!place.geometry) {
          return;
        }
        let icon = {
          url: place.icon,
          size: new google.maps.Size(71, 71),
          origin: new google.maps.Point(0, 0),
          anchor: new google.maps.Point(17, 34),
          scaledSize: new google.maps.Size(25, 25)
        };
        var markerRef = new google.maps.Marker({
          map: this.map,
          icon: 'assets/images/green_point.png',
          title: place.name,
          position: place.geometry.location
        });
        this.locationDetails.searchedLocation = place.name;
        this.locationDetails.searchedLocationLat = place.geometry.location.lat();
        this.locationDetails.searchedLocationLng = place.geometry.location.lng();
        this.locationDetails.searchedLocationRef = markerRef;
        // Create a marker for each place.
        markers.push(markerRef);
        if (place.geometry.viewport) {
          // Only geocodes have viewport.
          bounds.union(place.geometry.viewport);
        } else {
          bounds.extend(place.geometry.location);
        }
      });
      this.map.fitBounds(bounds);
    });
  }
  clearSelection() {
    if (this.selectedShape) {
      if (typeof this.selectedShape.setEditable == 'function') {
        this.selectedShape.setEditable(false);
      }
      this.selectedShape = null;
    }
  }
  updateCurSelText(shape) {
    if (this.selectedShape) {
      let coOrdinatesData = "";
      let drawingType = this.selectedShape.type;
      switch (drawingType) {
        case 'marker': {
          coOrdinatesData = this.selectedShape.getPosition().toUrlValue();
          console.log(coOrdinatesData);
        }
          break;
        case 'circle': {
          coOrdinatesData = this.selectedShape.getCenter().toUrlValue() + ';' + this.selectedShape.getRadius()
        }
          break;
        case 'polygon': {
          for (let i = 0; i < this.selectedShape.getPath().getLength(); i++) {
            coOrdinatesData += this.selectedShape.getPath().getAt(i).toUrlValue() + ";";
          }
        }
          break;
        case 'rectangle':
          coOrdinatesData = this.selectedShape.getBounds().toUrlValue();
          break;
      }
      this.locationDetails.drawings.filter(shape => shape.drawingId === this.selectedShape.id)[0].coOrdinates = coOrdinatesData;
    }
  }
  setSelection(shape, isNotMarker) {
    this.clearSelection();
    this.selectedShape = shape;
    if (isNotMarker)
      shape.setEditable(true);
    this.updateCurSelText(shape);
  }
  deleteDrawing(drawingId) {
    this.selectedShape = this.locationDetails.drawings.filter(shape => shape.drawingId === drawingId)[0].drawingShapeRef;
    this.locationDetails.drawings = this.locationDetails.drawings.filter(shape => shape.drawingId !== drawingId);
    if (this.selectedShape) {
      this.selectedShape.setMap(null);
    }
  }
  deleteSearchedDrawing() {
    this.locationDetails.searchedLocation = "";
    this.locationDetails.searchedLocationLat = 0;
    this.locationDetails.searchedLocationLng = 0;
    this.locationDetails.searchedLocationRef.setMap(null);
  }
  clearDrawings() {
    this.locationDetails.drawings.forEach(element => {
      element.drawingShapeRef.setMap(null);
    });
    this.locationDetails.drawings = [];
  }
  saveLocation() {
    this.locationDetails.drawings.forEach(element => {
      element.drawingShapeRef = null;
      element.drawingId = 0;
    });
    this.locationDetails.searchedLocationRef = null;
    // console.log(this.locationDetails)
    this.adminOutdoorService.addLocation(this.locationDetails).subscribe(res => {
      let locationId = res;
      alert("Saved Successfully - LocationId " + locationId)
    });
  }
}


