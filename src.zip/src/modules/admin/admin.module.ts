/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

/* Modules */
import { LayoutModule } from '../layout/layout.module';


/* Components */
import * as adminComponents from './components';

/* Containers */
import * as adminContainers from './containers';

/* Guards */
import * as adminGuards from './guards';

/* Services */
import * as adminServices from './services';
import { AdminAssetLocationComponent } from './components/admin-asset-location/admin-asset-location.component';
import { AssetVehicleMappingComponent } from './components/asset-vehicle-mapping/asset-vehicle-mapping.component';
import { ManageUsersComponent } from './components/manage-users/manage-users.component';


@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        ReactiveFormsModule,
        FormsModule,
        LayoutModule,
        NgSelectModule,
        Ng2SmartTableModule
    ],
    providers: [...adminServices.services, ...adminGuards.guards],
    declarations: [...adminContainers.containers, ...adminComponents.components, AdminAssetLocationComponent, AssetVehicleMappingComponent, ManageUsersComponent],
    exports: [...adminContainers.containers, ...adminComponents.components],
})
export class AdminModule {}
