import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Ng2SmartTableModule } from 'ng2-smart-table';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
//import { AdminAssetLocationComponent } from './modules/admin/component;




@NgModule({
    declarations: [AppComponent],
    imports: [BrowserAnimationsModule, AppRoutingModule, HttpClientModule,Ng2SmartTableModule ],
    providers: [],
    bootstrap: [AppComponent],
})
export class AppModule { }



