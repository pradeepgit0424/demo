import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
    {
        path: '',
        pathMatch: 'full',
        redirectTo: '/outdoor',
    },
    
    {
        path: 'outdoor',
        loadChildren: () =>
            import('../modules/outdoor/outdoor-routing.module').then(
                m => m.OutdoorRoutingModule
            ),
    },
    
    {
        path: 'indoor',
        loadChildren: () =>
            import('../modules/indoor/indoor-routing.module').then(
                m => m.IndoorRoutingModule
            ),
    },

    {
      path: 'admin',
      loadChildren: () =>
          import('../modules/admin/admin-routing.module').then(
              m => m.AdminRoutingModule
          ),
  }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
})
export class AppRoutingModule {}
